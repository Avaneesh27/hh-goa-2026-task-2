from app.extractive import Candidate, select_extractive_answer
from app.language import detect_language, normalize_text, to_sarvam_language_code, tokenize


def test_language_detection_and_tokenization_preserve_indic_text() -> None:
    assert detect_language("कॉर्पोरेशन म्हणजे काय?") == "hi"
    assert detect_language("கார்ப்பரேஷன் என்றால் என்ன?") == "ta"
    assert to_sarvam_language_code("mr") == "mr-IN"
    assert normalize_text("  hello\u00a0 world  ") == "hello world"
    assert "कॉर्पोरेशन" in tokenize("कॉर्पोरेशन म्हणजे काय?")


def test_extractive_answer_is_a_sentence_from_ranked_evidence() -> None:
    candidates = [
        Candidate(
            point_id=8,
            language="en",
            text="A corporation is a legal entity. It has rights and obligations separate from its owners.",
            source_query_id="q-8",
            fused_score=0.08,
            rerank_score=0.94,
        ),
        Candidate(
            point_id=9,
            language="en",
            text="A village council manages local services.",
            source_query_id="q-9",
            fused_score=0.02,
            rerank_score=0.10,
        ),
    ]

    answer = select_extractive_answer("What is a corporation?", candidates)

    assert answer is not None
    assert answer.candidate.point_id == 8
    assert answer.answer in candidates[0].text
    assert "legal entity" in answer.answer.lower()
