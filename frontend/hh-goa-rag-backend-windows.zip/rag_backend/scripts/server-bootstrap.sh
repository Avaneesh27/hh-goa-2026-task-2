#!/usr/bin/env bash
set -euo pipefail

install -d -m 0750 /opt/hh-goa-voice-rag
rsync -a --delete --exclude '.env' ./ /opt/hh-goa-voice-rag/
install -m 0644 systemd/hh-rag-api.service /etc/systemd/system/hh-rag-api.service
install -m 0644 systemd/hh-rag-ingest.service /etc/systemd/system/hh-rag-ingest.service
systemctl daemon-reload
systemctl enable --now hh-rag-api.service
echo "Create /opt/hh-goa-voice-rag/rag_backend/.env from .env.example, then run: systemctl start hh-rag-ingest.service"
