from __future__ import annotations

import sqlite3
import time
from collections import defaultdict
from pathlib import Path
from typing import Iterable

import numpy as np
from qdrant_client import QdrantClient

from .config import Settings
from .extractive import Candidate
from .language import tokenize


class RetrievalUnavailableError(RuntimeError):
    """Raised when neither evidence source can serve a query."""


class EmbeddingService:
    """Local embedding model. No hosted LLM or generative model is used."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._model = None

    def _load(self):
        if self._model is None:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(self._settings.embedding_model, device=self._device(self._settings.embedding_device))
        return self._model

    @staticmethod
    def _device(requested: str) -> str:
        if requested != "auto":
            return requested
        try:
            import torch
            return "cuda" if torch.cuda.is_available() else "cpu"
        except Exception:
            return "cpu"

    def encode(self, values: list[str]) -> list[list[float]]:
        if not values:
            return []
        batch_size = min(self._settings.embedding_batch_size, len(values))
        while True:
            try:
                vectors = self._load().encode(
                    values, batch_size=batch_size, normalize_embeddings=True, show_progress_bar=False, convert_to_numpy=True
                )
                return np.asarray(vectors, dtype=np.float32).tolist()
            except RuntimeError as error:
                is_cuda_oom = "out of memory" in str(error).casefold() and self._device(self._settings.embedding_device) == "cuda"
                if not is_cuda_oom or batch_size <= 8:
                    raise
                try:
                    import torch
                    torch.cuda.empty_cache()
                except Exception:
                    pass
                batch_size = max(8, batch_size // 2)


class LexicalIndex:
    """Durable Unicode FTS5/BM25 candidate source for exact multilingual matches."""

    def __init__(self, path: Path) -> None:
        self._path = path
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._connection = sqlite3.connect(self._path, check_same_thread=False)
        self._connection.execute("PRAGMA journal_mode=WAL")
        self._connection.execute("PRAGMA synchronous=NORMAL")
        self._connection.execute(
            "CREATE TABLE IF NOT EXISTS passage_catalog (point_id INTEGER PRIMARY KEY, language TEXT NOT NULL, text TEXT NOT NULL, source_query_id TEXT)"
        )
        self._connection.execute(
            "CREATE VIRTUAL TABLE IF NOT EXISTS passage_fts USING fts5(point_id UNINDEXED, language UNINDEXED, text, source_query_id UNINDEXED, tokenize='unicode61 remove_diacritics 2')"
        )
        self._connection.commit()

    def add_many(self, rows: Iterable[tuple[int, str, str, str | None]]) -> None:
        accepted: list[tuple[int, str, str, str | None]] = []
        for row in rows:
            result = self._connection.execute(
                "INSERT OR IGNORE INTO passage_catalog(point_id, language, text, source_query_id) VALUES (?, ?, ?, ?)", row
            )
            if result.rowcount:
                accepted.append(row)
        if accepted:
            self._connection.executemany(
                "INSERT INTO passage_fts(point_id, language, text, source_query_id) VALUES (?, ?, ?, ?)", accepted
            )
        self._connection.commit()

    def search(self, query: str, limit: int) -> list[Candidate]:
        terms = tokenize(query)
        if not terms:
            return []
        escaped_query = " OR ".join(f'"{term.replace(chr(34), "")}"' for term in terms[:24])
        rows = self._connection.execute(
            "SELECT point_id, language, text, source_query_id, bm25(passage_fts) AS rank FROM passage_fts WHERE passage_fts MATCH ? ORDER BY rank LIMIT ?",
            (escaped_query, limit),
        ).fetchall()
        return [
            Candidate(point_id=int(row[0]), language=str(row[1]), text=str(row[2]), source_query_id=row[3], fused_score=float(-row[4]), rerank_score=None)
            for row in rows
        ]

    def document_count(self) -> int:
        row = self._connection.execute("SELECT COUNT(*) FROM passage_catalog").fetchone()
        return int(row[0]) if row else 0


class HybridRetriever:
    def __init__(self, settings: Settings, embeddings: EmbeddingService, lexical: LexicalIndex) -> None:
        self._settings = settings
        self._embeddings = embeddings
        self._lexical = lexical
        self._qdrant = QdrantClient(url=settings.qdrant_url, api_key=settings.qdrant_api_key, timeout=15)
        self._reranker = None

    def _dense_search(self, query: str) -> list[Candidate]:
        vector = self._embeddings.encode([query])[0]
        result = self._qdrant.query_points(
            collection_name=self._settings.qdrant_collection,
            query=vector,
            using="dense",
            limit=self._settings.dense_top_k,
            with_payload=True,
        )
        candidates: list[Candidate] = []
        for point in result.points:
            payload = point.payload or {}
            candidates.append(
                Candidate(
                    point_id=int(point.id),
                    language=str(payload.get("language", "unknown")),
                    text=str(payload.get("text", "")),
                    source_query_id=str(payload.get("source_query_id")) if payload.get("source_query_id") is not None else None,
                    fused_score=float(point.score),
                    rerank_score=None,
                )
            )
        return candidates

    def _load_reranker(self):
        if self._reranker is None:
            from sentence_transformers import CrossEncoder
            self._reranker = CrossEncoder(self._settings.reranker_model, device=EmbeddingService._device(self._settings.reranker_device))
        return self._reranker

    @staticmethod
    def _fallback_rerank(query: str, candidates: list[Candidate]) -> list[Candidate]:
        query_terms = set(tokenize(query))
        ranked: list[Candidate] = []
        for candidate in candidates:
            overlap = len(query_terms & set(tokenize(candidate.text))) / max(1, len(query_terms))
            score = (0.72 * overlap) + (0.28 * min(1.0, candidate.fused_score * 100))
            ranked.append(Candidate(**{**candidate.__dict__, "rerank_score": score}))
        return ranked

    def search(self, query: str) -> tuple[list[Candidate], dict[str, float]]:
        dense_candidates: list[Candidate] = []
        lexical_candidates: list[Candidate] = []
        failures: list[str] = []
        started = time.perf_counter()
        try:
            dense_candidates = self._dense_search(query)
        except Exception as error:
            failures.append(f"dense index unavailable: {type(error).__name__}")
        dense_ms = (time.perf_counter() - started) * 1000
        started = time.perf_counter()
        try:
            lexical_candidates = self._lexical.search(query, self._settings.lexical_top_k)
        except Exception as error:
            failures.append(f"lexical index unavailable: {type(error).__name__}")
        lexical_ms = (time.perf_counter() - started) * 1000

        if not dense_candidates and not lexical_candidates and failures:
            raise RetrievalUnavailableError("; ".join(failures))

        fused: dict[int, Candidate] = {}
        scores: dict[int, float] = defaultdict(float)
        for candidates in (dense_candidates, lexical_candidates):
            for rank, candidate in enumerate(candidates, start=1):
                scores[candidate.point_id] += 1.0 / (self._settings.rrf_k + rank)
                fused.setdefault(candidate.point_id, candidate)

        fused_candidates = [
            Candidate(**{**candidate.__dict__, "fused_score": scores[point_id]})
            for point_id, candidate in fused.items()
        ]
        fused_candidates.sort(key=lambda candidate: candidate.fused_score, reverse=True)
        rerank_input = fused_candidates[: self._settings.rerank_top_k]
        if rerank_input:
            started = time.perf_counter()
            try:
                rerank_scores = self._load_reranker().predict([(query, candidate.text) for candidate in rerank_input])
                ranked = [Candidate(**{**candidate.__dict__, "rerank_score": float(score)}) for candidate, score in zip(rerank_input, rerank_scores)]
            except Exception:
                ranked = self._fallback_rerank(query, rerank_input)
            ranked.sort(key=lambda candidate: candidate.rerank_score or float("-inf"), reverse=True)
            rerank_ms = (time.perf_counter() - started) * 1000
        else:
            ranked, rerank_ms = [], 0.0
        return ranked, {"dense_retrieval": dense_ms, "lexical_retrieval": lexical_ms, "reranking": rerank_ms}
