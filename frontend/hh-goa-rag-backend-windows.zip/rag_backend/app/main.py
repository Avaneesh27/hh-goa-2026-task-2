from __future__ import annotations

import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from .config import get_settings
from .pipeline import DeterministicRagPipeline
from .retrieval import EmbeddingService, HybridRetriever, LexicalIndex
from .schemas import AnswerResponse, HealthResponse, TextQuery
from .stt import SarvamSpeechToText, SpeechToTextError


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    lexical = LexicalIndex(settings.lexical_db_path)
    embeddings = EmbeddingService(settings)
    app.state.settings = settings
    app.state.pipeline = DeterministicRagPipeline(settings, HybridRetriever(settings, embeddings, lexical))
    app.state.stt = SarvamSpeechToText(settings)
    yield


app = FastAPI(title="HH Goa Deterministic RAG", version="1.0.0", lifespan=lifespan)
settings = get_settings()
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.origin_list() or ["https://*.manus.space"],
    allow_credentials=True,
    allow_methods=["POST", "GET"],
    allow_headers=["Content-Type"],
)


@app.get("/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    runtime_settings = app.state.settings
    return HealthResponse(status="ok", embedding_model=runtime_settings.embedding_model, collection=runtime_settings.qdrant_collection)


@app.post("/v1/query/text", response_model=AnswerResponse)
async def text_query(request: TextQuery) -> AnswerResponse:
    return app.state.pipeline.answer(request.query, request.language_hint)


@app.post("/v1/query/voice", response_model=AnswerResponse)
async def voice_query(
    audio: UploadFile = File(...),
    language_hint: str | None = Form(default=None),
) -> AnswerResponse:
    started = time.perf_counter()
    try:
        transcript, language_code = await app.state.stt.transcribe(
            await audio.read(), audio.filename or "recording.webm", audio.content_type or "audio/webm", language_hint,
        )
    except SpeechToTextError as error:
        raise HTTPException(status_code=502, detail=str(error)) from error
    response = app.state.pipeline.answer(transcript, language_hint or language_code.split("-")[0], transcript=transcript)
    response.timing_ms["speech_to_text"] = (time.perf_counter() - started) * 1000 - response.timing_ms.get("total", 0.0)
    response.timing_ms["end_to_end"] = (time.perf_counter() - started) * 1000
    return response
