from __future__ import annotations

from pydantic import BaseModel, Field


class TextQuery(BaseModel):
    query: str = Field(min_length=1, max_length=2_000)
    language_hint: str | None = Field(default=None, max_length=16)


class Citation(BaseModel):
    point_id: int
    language: str
    passage: str
    fused_score: float
    rerank_score: float | None = None
    source_query_id: str | None = None


class AnswerResponse(BaseModel):
    status: str
    transcript: str | None = None
    detected_language: str
    answer: str | None = None
    reason: str | None = None
    citations: list[Citation] = []
    timing_ms: dict[str, float]


class HealthResponse(BaseModel):
    status: str
    embedding_model: str
    collection: str
    local_generation: bool = False
