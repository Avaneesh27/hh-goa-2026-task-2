from __future__ import annotations

import argparse
import hashlib
import json
import logging
import shutil
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from qdrant_client import QdrantClient, models
from tqdm import tqdm

from .config import Settings, get_settings
from .index_contract import ensure_collection, verify_collection_contract
from .language import normalize_text
from .retrieval import EmbeddingService, LexicalIndex

LOGGER = logging.getLogger("hh_rag.ingest")
DEFAULT_DATASET = "ai4bharat/MSMARCO-XI"
HUGGINGFACE_PARQUET_ROOT = "https://huggingface.co/datasets/ai4bharat/MSMARCO-XI/resolve/main"
OFFICIAL_SHARD_CODES = ("asm", "ben", "guj", "hin", "kan", "mal", "mar", "nep", "ori", "pan", "san", "tam", "tel", "urd")
DATASET_LANGUAGE_PREFIXES = {
    "asm": "as", "ben": "bn", "guj": "gu", "hin": "hi", "kan": "kn", "mal": "ml", "mar": "mr",
    "nep": "ne", "ori": "or", "pan": "pa", "san": "sa", "tam": "ta", "tel": "te", "urd": "ur",
}


@dataclass(frozen=True)
class PassageRecord:
    point_id: int
    language: str
    text: str
    source_query_id: str
    source_config: str
    selected: bool


class IngestState:
    """SQLite write-ahead state makes every batch restartable and auditable."""

    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self._connection = sqlite3.connect(path)
        self._connection.execute("PRAGMA journal_mode=WAL")
        self._connection.execute("PRAGMA synchronous=FULL")
        self._connection.execute(
            """CREATE TABLE IF NOT EXISTS checkpoints (
                dataset_config TEXT NOT NULL,
                split TEXT NOT NULL,
                next_offset INTEGER NOT NULL,
                processed_rows INTEGER NOT NULL,
                indexed_passages INTEGER NOT NULL,
                rejected_rows INTEGER NOT NULL,
                updated_at INTEGER NOT NULL,
                PRIMARY KEY (dataset_config, split)
            )"""
        )
        self._connection.execute(
            """CREATE TABLE IF NOT EXISTS rejects (
                dataset_config TEXT NOT NULL,
                split TEXT NOT NULL,
                source_offset INTEGER NOT NULL,
                reason TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                PRIMARY KEY (dataset_config, split, source_offset)
            )"""
        )
        self._connection.commit()

    def resume_offset(self, dataset_config: str, split: str) -> int:
        row = self._connection.execute(
            "SELECT next_offset FROM checkpoints WHERE dataset_config = ? AND split = ?", (dataset_config, split)
        ).fetchone()
        return int(row[0]) if row else 0

    def checkpoint(
        self, dataset_config: str, split: str, next_offset: int, processed_rows: int, indexed_passages: int, rejected_rows: int
    ) -> None:
        self._connection.execute(
            """INSERT INTO checkpoints(dataset_config, split, next_offset, processed_rows, indexed_passages, rejected_rows, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(dataset_config, split) DO UPDATE SET
              next_offset=excluded.next_offset, processed_rows=excluded.processed_rows,
              indexed_passages=excluded.indexed_passages, rejected_rows=excluded.rejected_rows,
              updated_at=excluded.updated_at""",
            (dataset_config, split, next_offset, processed_rows, indexed_passages, rejected_rows, int(time.time())),
        )
        self._connection.commit()

    def reject(self, dataset_config: str, split: str, source_offset: int, reason: str) -> None:
        self._connection.execute(
            "INSERT OR REPLACE INTO rejects(dataset_config, split, source_offset, reason, created_at) VALUES (?, ?, ?, ?, ?)",
            (dataset_config, split, source_offset, reason[:500], int(time.time())),
        )
        self._connection.commit()

    def summary(self) -> list[dict[str, Any]]:
        rows = self._connection.execute(
            "SELECT dataset_config, split, next_offset, processed_rows, indexed_passages, rejected_rows, updated_at FROM checkpoints ORDER BY dataset_config, split"
        ).fetchall()
        return [
            {
                "dataset_config": row[0], "split": row[1], "next_offset": int(row[2]), "processed_rows": int(row[3]),
                "indexed_passages": int(row[4]), "rejected_rows": int(row[5]), "updated_at": int(row[6]),
            }
            for row in rows
        ]


class DiskBudgetExceeded(RuntimeError):
    pass


def ensure_free_space(path: Path, min_free_gb: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    free_bytes = shutil.disk_usage(path.parent).free
    if free_bytes < min_free_gb * 1024**3:
        raise DiskBudgetExceeded(
            f"Stopped safely with {free_bytes / 1024**3:.2f} GiB free; minimum reserve is {min_free_gb} GiB."
        )


def stable_point_id(language: str, text: str) -> int:
    digest = hashlib.blake2b(f"{language}\0{normalize_text(text)}".encode("utf-8"), digest_size=8).digest()
    return int.from_bytes(digest, byteorder="big", signed=False) & ((1 << 63) - 1)


def _listify(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    if value is None:
        return []
    return [value]


def _first_text_value(source: dict[str, Any], preferred_keys: tuple[str, ...]) -> list[Any]:
    for key in preferred_keys:
        if key in source and source[key] is not None:
            return _listify(source[key])
    for key, value in source.items():
        if "passage" in key.casefold() or key.casefold() in {"text", "context", "document"}:
            return _listify(value)
    return []


def _passage_bundle(row: dict[str, Any]) -> dict[str, Any]:
    bundle = row.get("passages")
    return bundle if isinstance(bundle, dict) else row


def canonical_language(value: Any, fallback: str) -> str:
    raw = str(value or fallback).casefold()
    prefix = raw.split("_", maxsplit=1)[0].split("-", maxsplit=1)[0]
    return DATASET_LANGUAGE_PREFIXES.get(prefix, prefix)


def extract_passages(row: dict[str, Any], dataset_config: str, source_offset: int) -> list[PassageRecord]:
    bundle = _passage_bundle(row)
    language = canonical_language(row.get("target_lang") or row.get("language") or row.get("lang"), dataset_config)
    source_query_id = str(row.get("query_id") or row.get("id") or f"{dataset_config}:{source_offset}")
    texts = _first_text_value(
        bundle,
        (
            "Translated_passages", "translated_passages", "translated_passage_text",
            "passage_text", "passage", "text", "context", "document",
        ),
    )
    selections = _first_text_value(bundle, ("is_selected", "selected", "is_relevant"))
    rows: list[PassageRecord] = []
    for index, raw_text in enumerate(texts):
        text = normalize_text(str(raw_text or ""))
        if not text:
            continue
        selected = bool(selections[index]) if index < len(selections) else False
        rows.append(
            PassageRecord(
                point_id=stable_point_id(language, text), language=language, text=text,
                source_query_id=source_query_id, source_config=dataset_config, selected=selected,
            )
        )
    return rows


class CorpusIndexer:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.qdrant = QdrantClient(url=settings.qdrant_url, api_key=settings.qdrant_api_key, timeout=120)
        ensure_collection(self.qdrant, settings)
        verify_collection_contract(self.qdrant, settings)
        self.lexical = LexicalIndex(settings.lexical_db_path)
        self.embeddings = EmbeddingService(settings)

    def index_batch(self, records: Iterable[PassageRecord]) -> int:
        unique: dict[int, PassageRecord] = {record.point_id: record for record in records}
        rows = list(unique.values())
        if not rows:
            return 0
        vectors = self.embeddings.encode([record.text for record in rows])
        points = [
            models.PointStruct(
                id=record.point_id,
                vector={"dense": vector},
                payload={
                    "language": record.language,
                    "text": record.text,
                    "source_query_id": record.source_query_id,
                    "source_config": record.source_config,
                    "is_selected": record.selected,
                },
            )
            for record, vector in zip(rows, vectors, strict=True)
        ]
        self.qdrant.upsert(collection_name=self.settings.qdrant_collection, points=points, wait=True)
        self.lexical.add_many((record.point_id, record.language, record.text, record.source_query_id) for record in rows)
        return len(rows)


def stream_split(dataset_name: str, dataset_config: str, split: str, resume_offset: int):
    from datasets import load_dataset

    dataset = load_dataset(dataset_name, dataset_config, split=split, streaming=True)
    return dataset.skip(resume_offset) if resume_offset else dataset


def official_shards(split: str) -> list[tuple[str, str]]:
    suffix = "train" if split == "train" else "val"
    directory = "train" if split == "train" else "validation"
    return [
        (f"{directory}/{code}{suffix}.parquet", f"{HUGGINGFACE_PARQUET_ROOT}/{directory}/{code}{suffix}.parquet")
        for code in OFFICIAL_SHARD_CODES
    ]


def stream_parquet_rows(url: str, resume_offset: int, read_batch_rows: int = 256):
    """Read a remote Parquet shard in bounded record batches; no full row group is materialized."""
    import fsspec
    import pyarrow.parquet as pq

    with fsspec.open(url, "rb") as remote_file:
        parquet = pq.ParquetFile(remote_file)
        skipped = 0
        for batch in parquet.iter_batches(
            batch_size=read_batch_rows,
            columns=["target_lang", "query_id", "passages"],
            use_threads=True,
        ):
            for row in batch.to_pylist():
                if skipped < resume_offset:
                    skipped += 1
                    continue
                yield row


def ingest_config(
    indexer: CorpusIndexer,
    state: IngestState,
    dataset_name: str,
    dataset_config: str,
    split: str,
    batch_size: int,
    max_rows: int | None,
) -> dict[str, int]:
    resume_offset = state.resume_offset(dataset_config, split)
    processed_rows = resume_offset
    indexed_passages = 0
    rejected_rows = 0
    batch: list[PassageRecord] = []
    iterator = stream_split(dataset_name, dataset_config, split, resume_offset)
    progress = tqdm(iterator, desc=f"{dataset_config}:{split}", initial=resume_offset, unit="row")
    for offset, raw_row in enumerate(progress, start=resume_offset):
        if max_rows is not None and processed_rows >= max_rows:
            break
        try:
            records = extract_passages(dict(raw_row), dataset_config, offset)
            if not records:
                rejected_rows += 1
                state.reject(dataset_config, split, offset, "No non-empty passage could be extracted from row")
            else:
                batch.extend(records)
        except Exception as error:
            rejected_rows += 1
            state.reject(dataset_config, split, offset, f"row parsing failed: {type(error).__name__}: {error}")
        processed_rows = offset + 1
        if len(batch) >= batch_size:
            indexed_passages += indexer.index_batch(batch)
            batch = []
            state.checkpoint(dataset_config, split, processed_rows, processed_rows, indexed_passages, rejected_rows)
            progress.set_postfix(indexed=indexed_passages, rejected=rejected_rows)
    if batch:
        indexed_passages += indexer.index_batch(batch)
    state.checkpoint(dataset_config, split, processed_rows, processed_rows, indexed_passages, rejected_rows)
    return {"processed_rows": processed_rows, "indexed_passages": indexed_passages, "rejected_rows": rejected_rows}


def ingest_parquet_shard(
    indexer: CorpusIndexer,
    state: IngestState,
    shard_name: str,
    shard_url: str,
    split: str,
    batch_size: int,
    max_rows: int | None,
    min_free_gb: int,
) -> dict[str, int]:
    resume_offset = state.resume_offset(shard_name, split)
    processed_rows = resume_offset
    indexed_passages = 0
    rejected_rows = 0
    batch: list[PassageRecord] = []
    iterator = stream_parquet_rows(shard_url, resume_offset)
    progress = tqdm(iterator, desc=shard_name, initial=resume_offset, unit="row")
    try:
        for offset, raw_row in enumerate(progress, start=resume_offset):
            if max_rows is not None and processed_rows >= max_rows:
                break
            ensure_free_space(indexer.settings.lexical_db_path, min_free_gb)
            try:
                records = extract_passages(dict(raw_row), shard_name, offset)
                if not records:
                    rejected_rows += 1
                    state.reject(shard_name, split, offset, "No non-empty translated passage could be extracted from row")
                else:
                    batch.extend(records)
            except Exception as error:
                rejected_rows += 1
                state.reject(shard_name, split, offset, f"row parsing failed: {type(error).__name__}: {error}")
            processed_rows = offset + 1
            if len(batch) >= batch_size:
                ensure_free_space(indexer.settings.lexical_db_path, min_free_gb)
                indexed_passages += indexer.index_batch(batch)
                batch = []
                state.checkpoint(shard_name, split, processed_rows, processed_rows, indexed_passages, rejected_rows)
                progress.set_postfix(indexed=indexed_passages, rejected=rejected_rows)
    except DiskBudgetExceeded as error:
        state.checkpoint(shard_name, split, processed_rows, processed_rows, indexed_passages, rejected_rows)
        LOGGER.warning("%s", error)
        return {"processed_rows": processed_rows, "indexed_passages": indexed_passages, "rejected_rows": rejected_rows, "stopped_for_disk": 1}
    if batch:
        indexed_passages += indexer.index_batch(batch)
    state.checkpoint(shard_name, split, processed_rows, processed_rows, indexed_passages, rejected_rows)
    return {"processed_rows": processed_rows, "indexed_passages": indexed_passages, "rejected_rows": rejected_rows}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Resumable complete-corpus MSMARCO-XI ingestion")
    parser.add_argument("--dataset", default=DEFAULT_DATASET)
    parser.add_argument("--split", default="train")
    parser.add_argument("--source", choices=("parquet", "datasets"), default="parquet")
    parser.add_argument("--config", action="append", dest="configs", help="Dataset config to ingest; repeat for several configs")
    parser.add_argument("--all-configs", action="store_true", help="Discover and ingest every available dataset config")
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--max-rows", type=int, default=None, help="Validation cap only; omit for every row")
    parser.add_argument("--submission-mode", action="store_true", help="Use RTX 4050-safe row and disk limits")
    parser.add_argument("--min-free-gb", type=int, default=None, help="Stop safely before free disk falls below this value")
    parser.add_argument("--state-path", type=Path, default=Path("/var/lib/hh-rag/ingest-state.sqlite3"))
    parser.add_argument("--status", action="store_true")
    return parser.parse_args()


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    args = parse_args()
    state = IngestState(args.state_path)
    if args.status:
        print(json.dumps(state.summary(), indent=2))
        return
    indexer = CorpusIndexer(get_settings())
    max_rows = args.max_rows
    min_free_gb = args.min_free_gb if args.min_free_gb is not None else indexer.settings.min_free_gb
    if args.submission_mode and max_rows is None:
        max_rows = indexer.settings.submission_rows_per_shard
    outcomes = {}
    if args.source == "parquet":
        for shard_name, shard_url in official_shards(args.split):
            outcomes[shard_name] = ingest_parquet_shard(
                indexer, state, shard_name, shard_url, args.split, args.batch_size, max_rows, min_free_gb
            )
    else:
        if not args.configs and not args.all_configs:
            raise SystemExit("Pass --all-configs for every dataset configuration, or provide at least one --config.")
        if args.all_configs:
            from datasets import get_dataset_config_names
            configs = get_dataset_config_names(args.dataset)
        else:
            configs = args.configs
        for dataset_config in configs:
            outcomes[dataset_config] = ingest_config(
                indexer, state, args.dataset, dataset_config, args.split, args.batch_size, args.max_rows
            )
    print(json.dumps(outcomes, indent=2))


if __name__ == "__main__":
    main()
