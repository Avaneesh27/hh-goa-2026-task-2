from __future__ import annotations

from .config import get_settings
from .index_contract import verify_collection_contract
from .retrieval import EmbeddingService
from qdrant_client import QdrantClient


def main() -> None:
    settings = get_settings()
    vector = EmbeddingService(settings).encode(["multilingual retrieval preflight"])[0]
    if len(vector) != settings.embedding_dimensions:
        raise RuntimeError("Embedding model dimension does not match EMBEDDING_DIMENSIONS.")
    client = QdrantClient(url=settings.qdrant_url, api_key=settings.qdrant_api_key, timeout=30)
    verify_collection_contract(client, settings)
    print("preflight passed: local embedding model and Qdrant collection contract are ready")


if __name__ == "__main__":
    main()
