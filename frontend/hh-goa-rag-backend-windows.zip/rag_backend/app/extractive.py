from __future__ import annotations

import re
from dataclasses import dataclass

from .language import tokenize


SENTENCE_BOUNDARY = re.compile(r"(?<=[.!?।])\s+|\n+")


@dataclass(frozen=True)
class Candidate:
    point_id: int
    text: str
    language: str
    source_query_id: str | None
    fused_score: float
    rerank_score: float | None


@dataclass(frozen=True)
class ExtractedAnswer:
    answer: str
    candidate: Candidate
    confidence: float


def split_sentences(text: str) -> list[str]:
    return [sentence.strip() for sentence in SENTENCE_BOUNDARY.split(text) if len(sentence.strip()) >= 20]


def select_extractive_answer(query: str, candidates: list[Candidate]) -> ExtractedAnswer | None:
    query_terms = set(tokenize(query))
    best: ExtractedAnswer | None = None
    for candidate in candidates:
        for sentence in split_sentences(candidate.text):
            terms = set(tokenize(sentence))
            lexical_overlap = len(query_terms & terms) / max(1, len(query_terms))
            semantic = max(candidate.rerank_score or 0.0, candidate.fused_score)
            confidence = (0.62 * lexical_overlap) + (0.38 * min(1.0, max(0.0, semantic)))
            current = ExtractedAnswer(answer=sentence, candidate=candidate, confidence=confidence)
            if best is None or current.confidence > best.confidence:
                best = current
    return best
