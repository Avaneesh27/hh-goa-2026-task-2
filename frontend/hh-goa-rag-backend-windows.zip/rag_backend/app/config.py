from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime configuration. Secrets are supplied through environment variables only."""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    sarvam_api_key: str | None = Field(default=None, alias="SARVAM_API_KEY")
    sarvam_base_url: str = Field(default="https://api.sarvam.ai", alias="SARVAM_BASE_URL")
    sarvam_model: str = Field(default="saaras:v3", alias="SARVAM_STT_MODEL")

    qdrant_url: str = Field(default="http://qdrant:6333", alias="QDRANT_URL")
    qdrant_api_key: str | None = Field(default=None, alias="QDRANT_API_KEY")
    qdrant_collection: str = Field(default="msmarco_xi_passages_v1", alias="QDRANT_COLLECTION")
    lexical_db_path: Path = Field(default=Path("/var/lib/hh-rag/lexical.sqlite3"), alias="LEXICAL_DB_PATH")

    embedding_model: str = Field(
        default="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
        alias="EMBEDDING_MODEL",
    )
    reranker_model: str = Field(default="BAAI/bge-reranker-base", alias="RERANKER_MODEL")
    embedding_dimensions: int = Field(default=384, alias="EMBEDDING_DIMENSIONS")
    embedding_device: str = Field(default="auto", alias="EMBEDDING_DEVICE")
    reranker_device: str = Field(default="auto", alias="RERANKER_DEVICE")
    embedding_batch_size: int = Field(default=96, alias="EMBEDDING_BATCH_SIZE")
    min_free_gb: int = Field(default=12, alias="MIN_FREE_GB")
    submission_rows_per_shard: int = Field(default=50_000, alias="SUBMISSION_ROWS_PER_SHARD")
    dense_top_k: int = Field(default=40, alias="DENSE_TOP_K")
    lexical_top_k: int = Field(default=40, alias="LEXICAL_TOP_K")
    rerank_top_k: int = Field(default=30, alias="RERANK_TOP_K")
    answer_top_k: int = Field(default=3, alias="ANSWER_TOP_K")
    rrf_k: int = Field(default=60, alias="RRF_K")
    min_fused_score: float = Field(default=0.010, alias="MIN_FUSED_SCORE")
    min_extractive_score: float = Field(default=0.20, alias="MIN_EXTRACTIVE_SCORE")
    allowed_origins: str = Field(default="", alias="ALLOWED_ORIGINS")

    def origin_list(self) -> list[str]:
        return [origin.strip() for origin in self.allowed_origins.split(",") if origin.strip()]


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
