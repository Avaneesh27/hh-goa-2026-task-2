from __future__ import annotations

from qdrant_client import QdrantClient, models

from .config import Settings


def ensure_collection(client: QdrantClient, settings: Settings) -> None:
    if not client.collection_exists(settings.qdrant_collection):
        client.create_collection(
            collection_name=settings.qdrant_collection,
            vectors_config={
                "dense": models.VectorParams(
                    size=settings.embedding_dimensions,
                    distance=models.Distance.COSINE,
                    on_disk=True,
                )
            },
            hnsw_config=models.HnswConfigDiff(m=16, ef_construct=200, on_disk=True),
            optimizers_config=models.OptimizersConfigDiff(indexing_threshold=0, memmap_threshold=20_000),
            quantization_config=models.ScalarQuantization(
                scalar=models.ScalarQuantizationConfig(
                    type=models.ScalarType.INT8,
                    quantile=0.99,
                    always_ram=False,
                )
            ),
        )
        client.create_payload_index(
            collection_name=settings.qdrant_collection,
            field_name="language",
            field_schema=models.PayloadSchemaType.KEYWORD,
        )


def verify_collection_contract(client: QdrantClient, settings: Settings) -> None:
    collection = client.get_collection(settings.qdrant_collection)
    vectors = collection.config.params.vectors
    if not isinstance(vectors, dict) or "dense" not in vectors:
        raise RuntimeError("Qdrant collection is missing the required named vector 'dense'.")
    dense = vectors["dense"]
    if dense.size != settings.embedding_dimensions:
        raise RuntimeError(
            f"Qdrant vector size {dense.size} does not match EMBEDDING_DIMENSIONS={settings.embedding_dimensions}."
        )
