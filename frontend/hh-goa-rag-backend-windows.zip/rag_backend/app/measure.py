from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

from .config import get_settings
from .ingest import CorpusIndexer, IngestState, ingest_parquet_shard, official_shards


def directory_bytes(path: Path) -> int:
    if not path.exists():
        return 0
    return sum(item.stat().st_size for item in path.rglob("*") if item.is_file())


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Measure real submission-mode index growth before selecting a safe cap")
    parser.add_argument("--rows", type=int, default=1_000)
    parser.add_argument("--shard-index", type=int, default=0)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--state-path", type=Path, default=Path("data/ingest-state.sqlite3"))
    parser.add_argument("--reserved-free-gb", type=int, default=12)
    parser.add_argument("--report", type=Path, default=None)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    settings = get_settings()
    indexer = CorpusIndexer(settings)
    state = IngestState(args.state_path)
    shard_name, shard_url = official_shards("train")[args.shard_index]
    before = directory_bytes(args.data_root)
    started = time.perf_counter()
    result = ingest_parquet_shard(
        indexer=indexer,
        state=state,
        shard_name=shard_name,
        shard_url=shard_url,
        split="train",
        batch_size=min(96, args.rows),
        max_rows=args.rows,
        min_free_gb=args.reserved_free_gb,
    )
    elapsed = max(0.001, time.perf_counter() - started)
    after = directory_bytes(args.data_root)
    indexed = max(1, result["indexed_passages"])
    bytes_per_passage = max(1, after - before) / indexed
    usable_bytes = max(0, 50 * 1024**3 - args.reserved_free_gb * 1024**3 - after)
    recommendation_per_shard = int((usable_bytes / bytes_per_passage) / len(official_shards("train")))
    report = {
        "shard": shard_name,
        "elapsed_seconds": elapsed,
        "processed_rows": result["processed_rows"],
        "indexed_passages": result["indexed_passages"],
        "index_growth_bytes": after - before,
        "indexed_passages_per_second": indexed / elapsed,
        "bytes_per_indexed_passage": bytes_per_passage,
        "conservative_rows_per_shard_within_50_gb": max(0, recommendation_per_shard),
    }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
