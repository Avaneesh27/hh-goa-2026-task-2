from __future__ import annotations

import re
import unicodedata


SCRIPT_RANGES: tuple[tuple[str, range], ...] = (
    ("as", range(0x0980, 0x0A00)),
    ("bn", range(0x0980, 0x0A00)),
    ("gu", range(0x0A80, 0x0B00)),
    ("hi", range(0x0900, 0x0980)),
    ("kn", range(0x0C80, 0x0D00)),
    ("ml", range(0x0D00, 0x0D80)),
    ("mr", range(0x0900, 0x0980)),
    ("ne", range(0x0900, 0x0980)),
    ("or", range(0x0B00, 0x0B80)),
    ("pa", range(0x0A00, 0x0A80)),
    ("sa", range(0x0900, 0x0980)),
    ("ta", range(0x0B80, 0x0C00)),
    ("te", range(0x0C00, 0x0C80)),
    ("ur", range(0x0600, 0x0700)),
)

SARVAM_LANGUAGE_CODES: dict[str, str] = {
    "as": "as-IN", "bn": "bn-IN", "gu": "gu-IN", "hi": "hi-IN",
    "kn": "kn-IN", "ml": "ml-IN", "mr": "mr-IN", "ne": "ne-IN",
    "or": "od-IN", "pa": "pa-IN", "sa": "sa-IN", "ta": "ta-IN",
    "te": "te-IN", "ur": "ur-IN", "en": "en-IN",
}

def normalize_text(value: str) -> str:
    return " ".join(unicodedata.normalize("NFKC", value).strip().split())


def tokenize(value: str) -> list[str]:
    tokens: list[str] = []
    current: list[str] = []
    for character in normalize_text(value):
        category = unicodedata.category(character)
        if character.isalnum() or category.startswith("M"):
            current.append(character)
            continue
        if current:
            tokens.append("".join(current).casefold())
            current = []
    if current:
        tokens.append("".join(current).casefold())
    return tokens


def detect_language(value: str, fallback: str = "en") -> str:
    counts: dict[str, int] = {}
    for character in value:
        point = ord(character)
        for language, code_range in SCRIPT_RANGES:
            if point in code_range:
                counts[language] = counts.get(language, 0) + 1
                break
    if not counts:
        return fallback
    return max(counts, key=counts.get)


def to_sarvam_language_code(language: str | None) -> str:
    if not language or language in {"auto", "unknown"}:
        return "unknown"
    return SARVAM_LANGUAGE_CODES.get(language.casefold(), "unknown")
