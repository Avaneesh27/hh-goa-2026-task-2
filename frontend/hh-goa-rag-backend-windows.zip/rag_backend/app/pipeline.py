from __future__ import annotations

import time

from .config import Settings
from .extractive import select_extractive_answer
from .language import detect_language
from .retrieval import HybridRetriever, RetrievalUnavailableError
from .schemas import AnswerResponse, Citation


class DeterministicRagPipeline:
    """Retrieves and extracts directly from evidence; it never calls a text-generation model."""

    def __init__(self, settings: Settings, retriever: HybridRetriever) -> None:
        self._settings = settings
        self._retriever = retriever

    def answer(self, query: str, language_hint: str | None = None, transcript: str | None = None) -> AnswerResponse:
        started = time.perf_counter()
        language = language_hint or detect_language(query)
        try:
            candidates, timings = self._retriever.search(query)
        except RetrievalUnavailableError as error:
            return AnswerResponse(
                status="unavailable", transcript=transcript, detected_language=language,
                answer=None, reason=f"The retrieval service is not ready: {error}", citations=[],
                timing_ms={"total": (time.perf_counter() - started) * 1000},
            )
        timings["total_retrieval"] = (time.perf_counter() - started) * 1000
        if not candidates or candidates[0].fused_score < self._settings.min_fused_score:
            return AnswerResponse(
                status="abstained", transcript=transcript, detected_language=language,
                answer=None, reason="No sufficiently relevant evidence was found in the indexed corpus.", citations=[], timing_ms=timings,
            )

        extracted = select_extractive_answer(query, candidates[: self._settings.answer_top_k])
        if extracted is None or extracted.confidence < self._settings.min_extractive_score:
            return AnswerResponse(
                status="abstained", transcript=transcript, detected_language=language,
                answer=None, reason="Retrieved passages do not support a confident extractive answer.", citations=[], timing_ms=timings,
            )

        citations = [
            Citation(
                point_id=candidate.point_id, language=candidate.language, passage=candidate.text,
                fused_score=round(candidate.fused_score, 6), rerank_score=round(candidate.rerank_score, 6) if candidate.rerank_score is not None else None,
                source_query_id=candidate.source_query_id,
            )
            for candidate in candidates[: self._settings.answer_top_k]
        ]
        timings["total"] = (time.perf_counter() - started) * 1000
        return AnswerResponse(
            status="answered", transcript=transcript, detected_language=language, answer=extracted.answer,
            reason=None, citations=citations, timing_ms=timings,
        )
