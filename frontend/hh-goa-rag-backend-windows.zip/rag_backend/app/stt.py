from __future__ import annotations

import httpx

from .config import Settings
from .language import to_sarvam_language_code


class SpeechToTextError(RuntimeError):
    pass


class SarvamSpeechToText:
    """Thin server-side adapter for Sarvam STT; the API key never reaches the client."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings

    async def transcribe(
        self,
        audio_bytes: bytes,
        filename: str,
        content_type: str,
        language_hint: str | None,
    ) -> tuple[str, str]:
        if not self._settings.sarvam_api_key:
            raise SpeechToTextError("Speech transcription is not configured on this server.")
        if not audio_bytes:
            raise SpeechToTextError("The submitted audio file is empty.")

        files = {"file": (filename or "recording.webm", audio_bytes, content_type or "audio/webm")}
        data = {
            "model": self._settings.sarvam_model,
            "mode": "codemix",
            "language_code": to_sarvam_language_code(language_hint),
        }
        headers = {"api-subscription-key": self._settings.sarvam_api_key}
        timeout = httpx.Timeout(connect=10.0, read=45.0, write=45.0, pool=10.0)
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(f"{self._settings.sarvam_base_url}/speech-to-text", headers=headers, data=data, files=files)

        if response.status_code >= 400:
            raise SpeechToTextError(f"Sarvam transcription failed with status {response.status_code}.")
        payload = response.json()
        transcript = str(payload.get("transcript") or "").strip()
        if not transcript:
            raise SpeechToTextError("Sarvam did not return a transcript for this audio.")
        return transcript, str(payload.get("language_code") or "unknown")
