from __future__ import annotations

import argparse
import json
import time
from dataclasses import dataclass
from pathlib import Path

import fsspec
import pyarrow.parquet as pq

from .config import get_settings
from .ingest import HUGGINGFACE_PARQUET_ROOT, OFFICIAL_SHARD_CODES, canonical_language
from .pipeline import DeterministicRagPipeline
from .retrieval import EmbeddingService, HybridRetriever, LexicalIndex


@dataclass(frozen=True)
class BenchmarkRow:
    query: str
    language: str
    selected_passages: list[str]


def validation_urls() -> list[str]:
    return [f"{HUGGINGFACE_PARQUET_ROOT}/validation/{code}val.parquet" for code in OFFICIAL_SHARD_CODES]


def iter_validation_rows(max_rows_per_shard: int):
    for url in validation_urls():
        with fsspec.open(url, "rb") as remote_file:
            parquet = pq.ParquetFile(remote_file)
            seen = 0
            for batch in parquet.iter_batches(batch_size=64, columns=["query", "target_lang", "passages"], use_threads=True):
                for row in batch.to_pylist():
                    passages = row.get("passages") or {}
                    selected = [
                        text for text, flag in zip(
                            passages.get("Translated_passages") or [], passages.get("is_selected") or [], strict=False
                        ) if flag
                    ]
                    if row.get("query") and selected:
                        yield BenchmarkRow(
                            query=str(row["query"]),
                            language=canonical_language(row.get("target_lang"), "unknown"),
                            selected_passages=[str(text) for text in selected],
                        )
                        seen += 1
                        if seen >= max_rows_per_shard:
                            break
                if seen >= max_rows_per_shard:
                    break


def has_selected_evidence(citations, selected_passages: list[str]) -> bool:
    normalized_gold = {" ".join(text.split()) for text in selected_passages}
    return any(" ".join(citation.passage.split()) in normalized_gold for citation in citations)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evidence-first MSMARCO-XI validation benchmark")
    parser.add_argument("--rows-per-shard", type=int, default=50)
    parser.add_argument("--report", type=Path, default=Path("/var/lib/hh-rag/benchmark-report.json"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    settings = get_settings()
    retriever = HybridRetriever(settings, EmbeddingService(settings), LexicalIndex(settings.lexical_db_path))
    pipeline = DeterministicRagPipeline(settings, retriever)
    samples = list(iter_validation_rows(args.rows_per_shard))
    if not samples:
        raise RuntimeError("No labeled validation rows were found for benchmarking.")

    evidence_hits = 0
    answered = 0
    abstained = 0
    unavailable = 0
    total_latency = 0.0
    per_language: dict[str, dict[str, int]] = {}
    for sample in samples:
        started = time.perf_counter()
        response = pipeline.answer(sample.query, sample.language)
        total_latency += (time.perf_counter() - started) * 1000
        language = per_language.setdefault(sample.language, {"total": 0, "answered": 0, "evidence_hits": 0, "abstained": 0})
        language["total"] += 1
        if response.status == "answered":
            answered += 1
            language["answered"] += 1
            if has_selected_evidence(response.citations, sample.selected_passages):
                evidence_hits += 1
                language["evidence_hits"] += 1
        elif response.status == "abstained":
            abstained += 1
            language["abstained"] += 1
        else:
            unavailable += 1

    report = {
        "samples": len(samples),
        "answered": answered,
        "abstained": abstained,
        "unavailable": unavailable,
        "evidence_recall_at_3": evidence_hits / len(samples),
        "answer_rate": answered / len(samples),
        "mean_latency_ms": total_latency / len(samples),
        "per_language": per_language,
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
