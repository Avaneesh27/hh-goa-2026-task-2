"""Deterministic, non-generative multilingual RAG service."""
